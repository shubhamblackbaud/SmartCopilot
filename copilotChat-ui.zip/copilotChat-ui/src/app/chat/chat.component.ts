import { Component, Signal, signal } from '@angular/core';
@Component({
 selector: 'app-chat',
 standalone: true,
 templateUrl: './chat.component.html',
 styleUrls: ['./chat.component.scss']
})
export class ChatComponent {
 username: Signal<string> = signal('Cristen');
}
